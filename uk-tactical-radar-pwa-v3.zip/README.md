# UK Tactical Radar PWA

Installable military-styled UK air/sea radar using MapLibre, live ADS-B aircraft data and optional AIS vessel data.

## New: per-user API keys

The Settings panel lets each visitor save these values in their own browser:

- Data Proxy URL
- AISStream API key
- Optional ADS-B API key for future/custom providers

The values are stored in browser local storage on that device. They are not committed to GitHub and are not embedded into the PWA files. The AIS key is sent to the configured HTTPS data proxy only when AIS data is requested. The Node proxy keeps it in memory only and indexes active subscriptions by a SHA-256 fingerprint.

## Local/full-stack run

1. Install Node.js 20+.
2. Run `npm install`.
3. Optional: copy `.env.example` to `.env`.
4. Run `npm start`.
5. Open `http://localhost:8080`.
6. Open Settings. When frontend and backend share the same host, leave Data Proxy URL blank.

## GitHub Pages deployment (automatic)

GitHub Pages can host the static `public/` folder and provide the installable PWA, but GitHub Pages cannot run `server.js` or keep an AIS WebSocket open.

This project now includes `.github/workflows/deploy-pages.yml`. For a public deployment:

1. Create a GitHub repository and upload/push this whole project to its `main` branch.
2. In the repository open **Settings → Pages**.
3. Under **Build and deployment**, select **GitHub Actions** as the source.
4. Open the **Actions** tab. The `Deploy PWA to GitHub Pages` workflow publishes `public/` automatically.
5. GitHub shows the live URL when the workflow completes.

Every later push to `main` republishes the PWA automatically.

## Deploy the live-data proxy

`render.yaml` is included for a simple Node deployment on Render:

1. Sign in to Render and create a **Blueprint** from the same GitHub repository.
2. Set `ALLOWED_ORIGINS` to the exact GitHub Pages origin, for example `https://yourname.github.io` (no path and no trailing slash).
3. Deploy, then copy the resulting HTTPS service URL.
4. Open the installed radar PWA, choose **Settings**, paste that URL into **Data Proxy URL**, and save.
5. Add an AISStream key in the PWA only if vessel tracking is wanted.

Do not add visitors' AIS keys to GitHub or Render. Each visitor's key is stored on their own device and sent to the proxy only for AIS requests.

The app uses relative manifest/service-worker/icon paths so it works from a GitHub Pages project subdirectory as well as a root domain.

## Installation

On supported Chromium browsers the INSTALL APP button invokes the PWA installation prompt when available. On iPhone/iPad use Share → Add to Home Screen. HTTPS is required for normal production PWA and geolocation use.

## Data

- Aircraft: adsb.lol API by default (no key required).
- Military mode: adsb.lol `/v2/mil`, filtered to the selected radius by the proxy.
- Vessels: AISStream WebSocket through the proxy, with per-user keys supported.
- Map: MapLibre GL JS + OpenFreeMap/OpenStreetMap.

Public tracking data is not guaranteed to include every aircraft or vessel.
